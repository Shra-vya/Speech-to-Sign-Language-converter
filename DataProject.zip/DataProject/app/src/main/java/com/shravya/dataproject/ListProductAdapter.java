package com.shravya.dataproject;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.shravya.dataproject.R;



import java.util.List;



public class ListProductAdapter extends BaseAdapter {
    private Context mContext;
    private List<Product> mSigmlcode;

    public ListProductAdapter(Context mContext, List<Product> mSigmlcode) {
        this.mContext = mContext;
        this.mSigmlcode = mSigmlcode;
    }

    @Override
    public int getCount() {
        return mSigmlcode.size();
    }

    @Override
    public Object getItem(int position) {
        return mSigmlcode.get(position);
    }

    @Override
    public long getItemId(int position) {
        return mSigmlcode.get(position).getId();
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        View v = View.inflate(mContext, R.layout.item_listview,null);
        TextView words = (TextView)v.findViewById(R.id.words);
        TextView english = (TextView)v.findViewById(R.id.english);
        TextView kannada = (TextView)v.findViewById(R.id.kannada);
        TextView sigml = (TextView)v.findViewById(R.id.sigml_code);
        int position = 0;
        words.setText(mSigmlcode.get(position).getwords());
        english.setText(mSigmlcode.get(position).getenglish());
        kannada.setText(mSigmlcode.get(position).getkannada());
        sigml.setText(mSigmlcode.get(position).getsigml_code("practice"));
        return null;
    }
}
