package com.shravya.dataproject;

public class Product {
    private int id;
    private String words;
    private String english;
    private String kannada;
    private String sigml_code;

    public Product(int id, String words, String english,String kannada,String sigml_code) {
        this.id = id;
        this.words = words;
        this.english = english;
        this.kannada = kannada;
        this.sigml_code = sigml_code;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getwords() {
        return words;
    }

    public String getenglish() {
        return english;
    }

    public void setEnglish(String english) {
        this.english = english;
    }

    public String getkannada() {
        return kannada;
    }

    public void setkannada(String kannada) {
        this.kannada = kannada;
    }


    public String getsigml_code(String sigml_code) {
        return sigml_code;
    }

    public void setsigml_code(String sigml_code) {
        this.sigml_code = sigml_code;
    }
}
